#include "thread.h"

namespace aux
{

}