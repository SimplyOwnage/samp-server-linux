#ifndef SYSTOOLS_H_INCLUDED
#define SYSTOOLS_H_INCLUDED

#include <stddef.h>

size_t stackspace();

#endif
