#ifndef CAPI_H_INCLUDED
#define CAPI_H_INCLUDED

#include "api/ppcommon.h"

void ***get_api_table();

#endif
