# LawLess Roleplay - SA:MP Gamemode

## Overview
LawLess Roleplay is a custom SA:MP roleplay gamemode that includes features like personal vehicles, clothing purchases, and more. All systems are written from scratch, except for the libraries.

## Installation

### For Windows:
1. Run `samp-server.exe` to start the server.
2. Make sure each plugin ends with `.so`.

### For Linux:
1. Download the Linux folder from [www.samp.com](https://www.samp.com).
2. Move the files from the downloaded folder to this repository.
3. In `server.cfg`, make sure each plugin ends with `.so`.

## Configuration
- To modify server settings, edit `server.cfg`.
- To modify the gamemode, open `pawn.exe` from the `pawn` folder and select the gamemode you want to edit. The server is automatically compiled.

## Contact
- Skype: didko.bg@abv.bg
